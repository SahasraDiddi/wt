const allowRoles = (...roles)=>{
    return (Req,res,next)=>{
        if(!roles.includes(req.user.role)){
            return res.status(403).json({
                success:false,
                message:"Access denied"
           });
        next();
    };
}}
module.exports = allowRoles;