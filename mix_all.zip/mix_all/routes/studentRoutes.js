const express = require("express");
const router = express.Router();
const {createStudent,readStudent,getStudentById,updateStudent,deleteStudent} = require("../controllers/studentControllers");
const requireSessionAuth = require("../middleware/sessionAuth");
const allowRoles = require("../middleware/roleMiddleware");

router.post("/students",requireSessionAuth,allowRoles("admin","user"),createStudent);
router.get("/students",requireSessionAuth,allowRoles("user"),readStudent);
router.get("/students/:id",requireSessionAuth,allowRoles("admin"),getStudentById);
router.put("/students/:id",requireSessionAuth,allowRoles("admin"),updateStudent);
router.delete("/students/:id",requireSessionAuth,allowRoles("admin"),deleteStudent);

module.exports = router;